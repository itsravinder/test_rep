BizTalk-Json-Send-and-Receive-Pipelines
=======================================

BizTalk Send and Receive pipelines to convert from json to xml and xml to json.

For more details visit my blog:http://wcfbiztalk.wordpress.com/2013/08/31/json-send-and-receive-pipelines-for-biztalk-server-2/
